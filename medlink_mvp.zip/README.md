# MedLink MVP
A simple telemedicine MVP for demo purposes.