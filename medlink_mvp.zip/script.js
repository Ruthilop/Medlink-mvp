
console.log("MedLink MVP loaded!");
